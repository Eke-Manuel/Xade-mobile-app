import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

import { Button, TouchableOpacity } from 'react-native'

export default function App() {
  const handleSubmit = () => {}
  return (
    <View style = {styles.father}>
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        XADE
      </Text>
      <View style = {styles.boxes}>
        <View style={[styles.boxS, {backgroundColor: 'white'}]} />
        <View style={[styles.box, {backgroundColor: 'white'}]} />
        <View style={[styles.box, {backgroundColor: 'white'}]} />
        <View style={[styles.box, {backgroundColor: 'white'}]} />
        <View style={[styles.box, {backgroundColor: 'white'}]} />

      </View>
    
    </View>
    <View>
      <Text style = {styles.mainContent}>
        One app {"\n"}
        to manage {"\n"}
        all your  {"\n"}
        finances
      </Text>
    </View>
    <View style = {styles.subContent}>
    <Text style = {{color:'#979797', fontFamily: 'VelaSans-Medium'}}>
      A financial super app powered {"\n"}
      by advanced DeFi protocols
    </Text>
    </View>
     <View style = {styles.container2}>
         <View style = {styles.button}>
            <Text style = {styles.text}>
               Get started
            </Text>
         </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  father: {
    width: '100%',
    // height: '50%',
    // flex: 1,
    justifyContent: 'flex-start',
    backgroundColor: '#121212',
  },  
  container: {
    paddingRight: '10%',
    flex: 1,
    // justifyContent: 'center',
    flexDirection: 'row',
    width: '100%',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#121212',
    padding: 8,
    height: 20,
    justifyContent: 'space-between'
  },
  paragraph: {
    color: 'white',
    margin: 21,
    fontSize: 25,
    fontWeight: 'bold',
    fontFamily: 'LEMONMILK-Bold.otf'
    // textAlign: 'center',
  },
  boxS: {
    margin: 3,
    width: 15,
    height: 10,
    borderRadius: 100,
  },
  box: {
    margin: 3,
    width: 10,
    height: 10,
    borderRadius: 100,
    opacity: 0.3,
  },

  boxes: {
    margin: 28,
    marginRight: 10,
    flexDirection: 'row',
    justifySelf: 'flex-end'
  },

  mainContent: {
    color: 'white',
    paddingTop: '25%',
    paddingLeft: '10%',
    fontSize: 40,
    fontWeight: 600,
    fontFamly: 'VelaSans-Medium'
    // lineHeight: ,
  }, 

  subContent: {
    marginTop: 30,
    paddingLeft: '10%',
    color: '#FFFFFF',
    
  },

  text: {
    // width: '100%',
    // position: 'absolute',
    // right: 0,
    fontWeight: 500,
  },

  container2: {
    width: '100',
    alignItems: 'center',
    background: '#121212',
    paddingTop: 30,
    height: '20vh'
  },

  button: {
    width: '80%',
    height: '12vh',   
    paddingTop: '4vh',
    paddingLeft: 20,
    borderWidth: 1,
      // padding: 25,
      borderColor: 'black',
      background: 'linear-gradient(273.53deg, #E8FF59 -29.73%, #E8FF59 198.26%)',
      borderRadius: 15,
  }
});
